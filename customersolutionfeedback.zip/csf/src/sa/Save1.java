package sa;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Save1
 */
@WebServlet("/Save1")
public class Save1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("html/text");
		PrintWriter out=response.getWriter();
		String ename=request.getParameter("ename");
		String eid=request.getParameter("eid");
		String feedback=request.getParameter("feedback");
		Emp1 e=new Emp1();
		e.setEname(ename);
		e.setEid(eid);
		e.setFeedback(feedback);
		int s=0;
		try {
			s=EmpDao.save(e);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if(s>0)
		{
			out.print("Feedback added successfully");
		}
		else
		{
			out.print("Some problem in your connection");
		}

	}

}
