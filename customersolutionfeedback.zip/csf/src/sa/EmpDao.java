package sa;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class EmpDao {

	public static int save(Emp e) {
		int s=0;
		try
		{
			PreparedStatement p=((java.sql.Connection) EmpDao.getConnection()).prepareStatement("insert into custdetail(name,email,phone,username,password) values(?,?,?,?,?)");
			p.setString(1, e.getName());
			p.setString(2, e.getEmail());
			p.setString(3, e.getPhone());
			p.setString(4, e.getUsername());
			p.setString(5, e.getPassword());
			s=p.executeUpdate();
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
		return s;
	}

	private static Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=null;
		return con=(Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ajith", "root", "");
	}

	public static int cmp(New n) {
		int ss=0;
		String n1=n.getUsername();
		String p=n.getPassword();
		/*Scanner s=new Scanner(System.in);
		String name=s.next();
		String password=s.next();*/
		try
		{
			Statement st=(Statement) EmpDao.getConnection().createStatement();
			ResultSet r=st.executeQuery("select username,password from custdetail");
			while(r.next())
			{
				
				if(n1.equals(r.getString("username"))&&(p.equals(r.getString("password"))))
				{
					//s1=1;
					return ss=1;
					//System.out.print("Login Successfully");
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
			//return s;
		return ss;
	}

	public static int save(Emp1 e) throws ClassNotFoundException, SQLException {
		int s=0;
		try
		{
			PreparedStatement p=((java.sql.Connection) EmpDao.getConnection()).prepareStatement("insert into feedback(ename,rating,feed)values(?,?,?)");
			p.setString(1, e.getEname());
			p.setString(2, e.getEid());
			p.setString(3, e.getFeedback());
			s=p.executeUpdate();
		}
		catch(Exception e1)
		{
			e1.printStackTrace();
		}
		return s;
	}

}
